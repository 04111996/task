import React from 'react';

export default class Test extends React.Component {
  render() {
    return <div>Hi from component</div>;
  }
}
