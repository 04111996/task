// Obsolete
const EnhancedHeadingCell = OriginalComponent => OriginalComponent;

export default EnhancedHeadingCell;
