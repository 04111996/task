import React from 'react';

// We're not going to be displaying a pagination bar for infinite scrolling.
const PaginationComponent = (props) => <span />;

export default PaginationComponent;
