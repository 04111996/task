import Pagination from './Pagination';
import SpacerRow from './SpacerRow';
import TableBody from './TableBody';
import TableEnhancer from './TableEnhancer';

export default {
  Pagination,
  SpacerRow,
  TableBody,
  TableEnhancer,
}
