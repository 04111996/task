import TableHeadingCellContainer from '../../../components/TableHeadingCellContainer';

// Obsolete
const EnhancedHeadingCell = TableHeadingCellContainer;

export default EnhancedHeadingCell;
