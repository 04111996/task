import { FakeData } from "./fakeData";

declare class person {
    constructor(data: FakeData);
}

declare class personClass {
    constructor(data: FakeData);
}

declare const fakeData2: person[];
declare const fakeData3: personClass[];
